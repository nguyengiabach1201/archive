#include <cmath>
#include <iostream>
using namespace std;

int main() {
  int a, n;
  cout << "Nhập a\n";
  cin >> a;
  cout << "Nhập n\n";
  cin >> n;

  cout << pow(a, n);
}